import os
import time
import platform
import json

save_file = "save.json"

def load_save():
    if not os.path.exists(save_file):
        data = {"installed": False, "name": "", "password": ""}
        with open(save_file, "w") as f:
            json.dump(data, f)
    with open(save_file) as f:
        return json.load(f)

def save_data(data):
    with open(save_file, "w") as f:
        json.dump(data, f)

data = load_save()

print("""
Welcome to portotype os
Helol to portotype Welcome...
saxende:Samyar jahani
""")

time.sleep(3)

print("درحال بوت شدن...")
time.sleep(6)

if data["installed"] == False:

    print("""
مرحله اول:
نصب سيستم عامل ...
لطفا صبر کنيد اين نصب سيستم عامل حدود 30 دقيقه ي طول مي کشه
""")

    time.sleep(10)

    print("""
نصب کامل شد!
مرحله 2:
براي اکانت خودتون اسم و رمز بزاريد.
""")

    name = input("اسم اکانت را بزاريد:")
    ppp = input("پسورد اکانت را انتخاب کنيد:")

    data["installed"] = True
    data["name"] = name
    data["password"] = ppp

    save_data(data)

else:
    name = data["name"]
    ppp = data["password"]

print("خوش آمديد " + name)

ooo = input("رمز را بگيد:")

if ooo == ppp:

    print("""
---------------------- منو استارت -----------
1.باز کردن فايل منجير
2.باز کردن نوتپد
3.باز کردن ماشين خساب
4.موزيک ها
5.آپديت
6.تنظيمات
""")

    ch = input("انتخاب شما چيست؟:")

    if ch == "1":
        os.startfile(r"C:/Users/Samyar.j/Desktop/prototypeOS/prototype/system32/برنامه ها و موزیک و سیستم عامل/برنامه/file_manager/file_manager.py")

    if ch == "2":
        os.startfile(r"C:/Users/Samyar.j/Desktop/prototypeOS/prototype/system32/برنامه ها و موزیک و سیستم عامل/برنامه/notepad/notepad.py")

    if ch == "3":
        os.startfile(r"C:/Users/Samyar.j/Desktop/prototypeOS/prototype/system32/برنامه ها و موزیک و سیستم عامل/برنامه/calculator/calculator.py")

    if ch == "4":

        print("---------- ليست موزيک ها ------")

        print("""
1.موزيک 1
2.موزيک 2
3.موزيک 3
""")

        ggg = input("انتخاب شما:")

        if ggg == "1":
            os.startfile(r"C:/Users/Samyar.j/Desktop/prototypeOS/prototype/system32/برنامه ها و موزیک و سیستم عامل/برنامه/mo.mp3")

        if ggg == "2":
            os.startfile(r"C:/Users/Samyar.j/Desktop/prototypeOS/prototype/system32/برنامه ها و موزیک و سیستم عامل/برنامه/Modern Talking - Brother Louie 2005.mp3")

        if ggg == "3":
            os.startfile(r"C:/Users/Samyar.j/Desktop/prototypeOS/prototype/system32/برنامه ها و موزیک و سیستم عامل/برنامه/Modern Talking - Chery Chery Lady.mp3")

    if ch == "5":

        print("لطفا صبر کنيد تا آپديت تمام شود...")
        time.sleep(4)

        print("----------------- برنامه هاي جديد اضافه شد! -----------")

        print("""
1.run
2.نمايش مخصات سيستم
3.نسخه پيشرفته سيستم عامل
""")

        jjj = input("انتخاب شما:")

        if jjj == "1":

            ddd = input("مسير را بديد براي اجرا برنامه: ")

            try:
                os.startfile(ddd)
                print("برنامه با موفقيت اجرا شد!")
            except:
                print("خطا: مسير وجود نداشت")

        if jjj == "2":

            print("\n--- اطلاعات سيستم ---")
            print("سيستم عامل: پروتوتايپ")
            print("نسخه:", platform.version())
            print("پردازنده:", platform.processor())

    if ch == "6":

        print("""
-------------------------- تنظيمات ---------------------
1.تغير نام اکانت
2.تغير رمز
3.اجراي ترمينال
""")

        mh = input("انتخاب شما:")

        if mh == "1":
            name = input("نام جديد را وارد کنيد:")
            data["name"] = name
            save_data(data)
            print("نام با موفقيت تغيير کرد!")

        if mh == "2":
            ppp = input("رمز جديد را وارد کنيد:")
            data["password"] = ppp
            save_data(data)
            print("رمز عبور با موفقيت تغيير کرد!")

        if mh == "3":

            print("-------- پروتوتايپ ترمينال --------")

            while True:

                print("پروتوتايپ 0.1 پروتوتايپ ترمينال <ورژن 0.1.3.6>است")

                cmd = input("c:\\portotayp\\system32\\>")

                if cmd == "samyar":
                    print("""
ساميار يک پسر 11ساله باهوش
است يعني سازنده سيستم عامل پروتوتايپ
اون عاشق تکنلوژِي و کامپيوتر و برنامه نويسي است
""")

                if cmd == "system_amel":
                    print("""
پروتوتايپ 0.1
ورژن:0.3
""")

                if cmd == "خروج":
                    break

else:
    print("رمز اشتباه است")
