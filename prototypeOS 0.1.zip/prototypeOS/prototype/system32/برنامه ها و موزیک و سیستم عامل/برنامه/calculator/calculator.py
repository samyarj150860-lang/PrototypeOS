import tkinter as tk

class PrototypeCalculator:

    def __init__(self, root):
        self.root = root
        self.root.title("Prototype OS - Calculator")
        self.root.geometry("300x400")

        self.expression = ""

        self.display = tk.Entry(root, font=("Consolas", 18), bd=10, relief="ridge", justify="right")
        self.display.pack(fill="both", padx=10, pady=10)

        buttons = [
            ['7','8','9','/'],
            ['4','5','6','*'],
            ['1','2','3','-'],
            ['0','.','=','+'],
            ['C']
        ]

        frame = tk.Frame(root)
        frame.pack()

        for row in buttons:
            row_frame = tk.Frame(frame)
            row_frame.pack(expand=True, fill="both")
            for btn in row:
                button = tk.Button(
                    row_frame,
                    text=btn,
                    font=("Consolas", 14),
                    height=2,
                    width=5,
                    command=lambda b=btn: self.click(b)
                )
                button.pack(side="left", expand=True, fill="both")

    def click(self, value):

        if value == "=":
            try:
                result = str(eval(self.expression))
                self.display.delete(0, tk.END)
                self.display.insert(tk.END, result)
                self.expression = result
            except:
                self.display.delete(0, tk.END)
                self.display.insert(tk.END, "Error")
                self.expression = ""

        elif value == "C":
            self.expression = ""
            self.display.delete(0, tk.END)

        else:
            self.expression += value
            self.display.delete(0, tk.END)
            self.display.insert(tk.END, self.expression)


if __name__ == "__main__":
    root = tk.Tk()
    app = PrototypeCalculator(root)
    root.mainloop()
