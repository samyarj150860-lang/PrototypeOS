import tkinter as tk
from tkinter import filedialog
import os

class PrototypeFileManager:

    def __init__(self, root):
        self.root = root
        self.root.title("Prototype OS - File Manager")
        self.root.geometry("700x500")

        self.current_path = os.getcwd()

        self.path_label = tk.Label(root, text=self.current_path, anchor="w")
        self.path_label.pack(fill="x")

        self.listbox = tk.Listbox(root, font=("Consolas", 12))
        self.listbox.pack(fill="both", expand=True)

        self.listbox.bind("<Double-Button-1>", self.open_item)

        top_frame = tk.Frame(root)
        top_frame.pack(fill="x")

        back_btn = tk.Button(top_frame, text="Back", command=self.go_back)
        back_btn.pack(side="left")

        refresh_btn = tk.Button(top_frame, text="Refresh", command=self.load_files)
        refresh_btn.pack(side="left")

        open_btn = tk.Button(top_frame, text="Open File", command=self.open_file_dialog)
        open_btn.pack(side="left")

        self.load_files()

    def load_files(self):
        self.listbox.delete(0, tk.END)
        self.path_label.config(text=self.current_path)

        try:
            for item in os.listdir(self.current_path):
                self.listbox.insert(tk.END, item)
        except:
            pass

    def open_item(self, event):
        selected = self.listbox.get(self.listbox.curselection())
        path = os.path.join(self.current_path, selected)

        if os.path.isdir(path):
            self.current_path = path
            self.load_files()
        else:
            os.startfile(path)

    def go_back(self):
        self.current_path = os.path.dirname(self.current_path)
        self.load_files()

    def open_file_dialog(self):
        filedialog.askopenfilename()

if __name__ == "__main__":
    root = tk.Tk()
    app = PrototypeFileManager(root)
    root.mainloop()
